# CNN 输入敏感性与20%遗忘：五项任务结果

打开 [完整研究报告](research/cnn_sensitivity/README.md)，图表位于 `research/cnn_sensitivity/figures/`。

- 输入说明：140个原始编码坐标，64个学习到的隐藏坐标。
- CNN前向调用图、实测形状和预测到cost路径图。
- 单个坐标乘1.1的预测与cost响应，原始/20%遗忘模型对比。
- 固定样本及24个测试时点，共9792次干预，所有两阶段求解正常完成。
- 完整数值、真实输入及冻结模型快照，可直接重放。

## 使用快照重放

在本文件夹中，使用项目已配置的Python 3.10环境及requirements.txt中的依赖：

```bash
python scripts/analyze_cnn_sensitivity.py --replay-from research/cnn_sensitivity --output-dir /tmp/cnn_sensitivity_replay
python scripts/validate_cnn_sensitivity.py --replay-dir /tmp/cnn_sensitivity_replay
python -m pytest tests -q
```

快照重放无需原始年度数据或重新训练CNN，也支持从GitHub ZIP解压的无Git元数据目录运行。输出目录须为空。原始数据重建模式则仍需原仓库中的完整数据、检查点和影响分数。

图表已导出PNG/PDF，流程图另有SVG/DOT。重新绘制流程图需要Graphviz；已有导出文件可以直接查看。包中的 `SHA256SUMS.txt` 可用于检查所有文件。
