# CNN 温度扰动实验下载包

先打开 research/cnn_temperature_response/导师汇报.md；三张实验图和一张流程图在该目录 figures/，均有 PNG/PDF。
完整方法、实际数据、局限和命令在 research/cnn_temperature_response/README.md。

此包含四种真实冻结模型、一个真实测试样本及官方选中节点全年原温度。
不含完整年度数据、历史 influence 文件或虚拟环境；复算本次五档曲线无需重新训练或下载全年数据。
如果要从头重新生成所有权重，则仍需完整数据和原影响分数，见成本复现报告。

Python 3.10，依赖见 requirements.txt；普通运行优先 GUROBI，auto 可回退兼容求解器。
在解压的项目根目录执行：

```bash
python3.10 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
.venv/bin/python experiments/input_sensitivity.py --replay-from research/cnn_temperature_response --output-dir /tmp/temperature-replay-new
.venv/bin/python experiments/report_temperature_response.py
.venv/bin/python experiments/validate_temperature_response.py --replay-dir /tmp/temperature-replay-new
.venv/bin/python -m pytest -q
```

绘制流程图需系统安装 Graphviz（dot）；现成 PNG/PDF 已包含。/tmp 输出目录须为空。
Cost 沿用原目标函数和约束。结果来自单节点、单样本、单种子干预，不作天气因果或总体推断。
SHA256SUMS 可校验每个文件。
