# 实验图表导出

三个模型的图表分别位于 `linear/`、`cnn/`、`mlp/`，其中 MLP 对应 MLP-Mixer。

| 模型 | MSE / MAPE / Cost 三联图 | 矢量 PDF |
| --- | --- | --- |
| Linear | [PNG](linear/unlearning_metrics.png) | [PDF](linear/unlearning_metrics.pdf) |
| CNN | [PNG](cnn/unlearning_metrics.png) | [PDF](cnn/unlearning_metrics.pdf) |
| MLP-Mixer | [PNG](mlp/unlearning_metrics.png) | [PDF](mlp/unlearning_metrics.pdf) |

每个模型文件夹内另有 `mse.png/pdf`、`mape.png/pdf`、`cost.png/pdf` 九张独立单图。

- `unlearning_metrics.csv`：54 行原始数值，包括三个集合、六个遗忘比例及三个模型。
- `unlearning_metrics.json`：完整数值和运行溯源信息。
- `FIGURE_REPRODUCTION_REPORT.md`：本次六比例图表的结果及复现报告。
- `COST_REPRODUCTION_REPORT.md`：此前 cost 修复报告；关联的旧权重约束曲线作为附录保存在 `outputs/cost-debug/`。
- `scripts/`：原始批量评估与绘图脚本。
- `SHA256SUMS.txt`：导出文件的 SHA-256 校验清单。

文件复制自分支 `fix/cost-evaluation` 的提交 `5e86aff`。图表和数值文件保持原字节，报告中的相对图片链接已适配本文件夹。

使用现有 Python 环境中的 NumPy、Matplotlib，可从 JSON 重绘：

```bash
python scripts/plot_unlearning_proportions.py --metrics-json unlearning_metrics.json --output-dir redrawn
```

完整训练和 cost 重算命令仍需在原项目仓库中运行；本导出包不包含大型原始数据、模型检查点及全部评估日志。
